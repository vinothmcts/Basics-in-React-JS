import React from 'react';
import ReactDOM from 'react-dom';


class Components extends React.Component {
      constructor(props){
            super(props);
            this.state = {
                  propsInfo:''
            }
            this.propsUpdate = this.propsUpdate.bind(this);
      }

      componentWillMount() {
            console.log(this,'Component WILL MOUNT!');
      }
      
      componentDidMount() {
            console.log(this,'Component DID MOUNT!');
      }
      componentWillReceiveProps(newProps) {    
            console.log(this,'Component WILL RECIEVE PROPS!');
      }
      shouldComponentUpdate(newProps, newState) {
            console.log(this,'shouldComponentUpdate');
            return true;
      }
      componentWillUpdate(nextProps, nextState) {
            console.log(this,'Component WILL UPDATE!');
      }
      componentDidUpdate(prevProps, prevState) {
            console.log(this,'Component DID UPDATE!');
      }
      componentWillUnmount() {
            console.log(this,'Component WILL UNMOUNT!');
      }      

      propsUpdate(ev){
            this.setState({propsInfo:ev.target.value});
      }

	render() {
	      return (
	         <div>
	            <Header propsUpdate = {this.propsUpdate} propsInfo ={this.state.propsInfo}/>
	            <Content propsInfo ={this.state.propsInfo}/>
	         </div>
	      );
	}
}
class Header extends React.Component {
      constructor(props){
            super(props);
            this.state = {
                  stateInfo:props.propsInfo
            }
      }

      componentWillMount() {
            console.log(this,'Component WILL MOUNT!');
      }
      
      componentDidMount() {
            console.log(this,'Component DID MOUNT!');
      }
      componentWillReceiveProps(newProps) {    
            console.log(this,'Component WILL RECIEVE PROPS!');
            this.setState({stateInfo:newProps.propsInfo});
      }
      shouldComponentUpdate(newProps, newState) {
            console.log(this,'shouldComponentUpdate');
            return true;
      }
      componentWillUpdate(nextProps, nextState) {
            console.log(this,'Component WILL UPDATE!');
      }
      componentDidUpdate(prevProps, prevState) {
            console.log(this,'Component DID UPDATE!');
      }
      componentWillUnmount() {
            console.log(this,'Component WILL UNMOUNT!');
      }

      render() {
      return (
         <div>
            <h1 className="heading">Header</h1>
            <input value={this.state.stateInfo} onChange={(ev)=>this.props.propsUpdate(ev)} />
            <p>Updated parent state value: {this.state.stateInfo}</p>
         </div>
      );
   }
}

class Content extends React.Component {
      constructor(props){
            super(props);
            this.state = {
                  stateInfo:props.propsInfo
            }
            this.stateUpdate = this.stateUpdate.bind(this);            
      }
      stateUpdate(ev){
            this.setState({stateInfo:ev.target.value});
      }

      componentWillMount() {
            console.log(this,'Component WILL MOUNT!');
      }
      
      componentDidMount() {
            console.log(this,'Component DID MOUNT!');
      }
      componentWillReceiveProps(newProps) {    
            console.log(this,'Component WILL RECIEVE PROPS!');
            this.setState({stateInfo:newProps.propsInfo});
      }
      shouldComponentUpdate(newProps, newState) {
            console.log(this,'shouldComponentUpdate');
            return true;
      }
      componentWillUpdate(nextProps, nextState) {
            console.log(this,'Component WILL UPDATE!');
      }
      componentDidUpdate(prevProps, prevState) {
            console.log(this,'Component DID UPDATE!');
      }
      componentWillUnmount() {
            console.log(this,'Component WILL UNMOUNT!');
      }

      render() {
      return (
         <div>
            <h1 className="heading">Content</h1>
            <input value={this.state.stateInfo} onChange={(ev)=>this.stateUpdate(ev)} />
            <p>Updated current component state value &amp; Updated parents value: {this.state.stateInfo}</p>
         </div>
      );
   }
}

export default Components;